const satellite = document.getElementById('satellite');
const moon = document.querySelector('.moon');

satellite.addEventListener('click', () => {
  satellite.style.bottom = '260px'; // simulate landing
});

moon.addEventListener('click', () => {
  satellite.style.bottom = '0';
});

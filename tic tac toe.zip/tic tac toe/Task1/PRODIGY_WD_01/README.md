# PRODIGY_WD_01
Task 1 RCB(Royal Challengers Bangalore) responsive landing page.

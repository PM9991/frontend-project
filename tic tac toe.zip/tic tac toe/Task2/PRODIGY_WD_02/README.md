# PRODIGY_WD_02
Stopwatch designed using HTML, CSS and Javascript with Stop/Start , Reset and Record functionalities.
